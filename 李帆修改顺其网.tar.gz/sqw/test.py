import re
import requests

res = requests.get('http://www.11467.com/qiye/61.htm', allow_redirects=False)

print(res.status_code)

print(res.text)