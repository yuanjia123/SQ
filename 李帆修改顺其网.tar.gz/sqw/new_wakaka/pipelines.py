# -*- coding: utf-8 -*-
# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import psycopg2
import json
import re
from new_wakaka.SQL_word import log

class NewWakakaPipeline(object):
    def open_spider(self, spider):
        self.file = open("SQ2.json", "w", encoding="utf-8")

    def process_item(self, item, spider):
        content = json.dumps(dict(item), ensure_ascii=False) + "\n"
        #self.file.write(content)
        return item

    def close_spider(self, spider):
        self.file.close()

class SqlPipline(object):

    def open_spider(self, spider):
        print('开始')


    def process_item(self, item, spider):
        l = log()
        conn = psycopg2.connect(database=l.database, user=l.user, password=l.password, host=l.host, port=l.port)
        # 产生一个游标
        cur = conn.cursor()
        item_my = dict(item)

        if item_my['shop_range'] == None:
            item_my['shop_range'] = item_my['main_project']


        try:
            item_my['company_num'] = int(item_my['company_num'])
            cur.execute(
                "INSERT INTO bjzs_big_data.baoji_company(lng,lat,province,city,area,"
                "name,business_scope,uniform_credit_code,r_a,verify_date,"
                "business_status,open_date,regist_money,business_type,sq_code,"
                "address,phone,legal_person,email,introduction, money_type) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, %s)",
                (item_my['lng'],item_my['lat'],item_my['province'],item_my['city'],item_my['area'],
                    item_my['company_name'], item_my['shop_range'], item_my['business_num'], item_my['send_office'],item_my['check_date'],
                    item_my['run_status'], item_my['set_date'], item_my['register_money'], item_my['type1'],item_my['company_num'],
                    item_my['company_location'],item_my['call'],item_my['manager'],item_my['email_address'],item_my['company_introduce'], item_my['money_type']))
            #提交
            conn.commit()
        except Exception as err:
            print('存入数据出错', err)

        #关闭游标
        finally:
            if cur:
                cur.close()
            conn.close()
        #给引擎返回数据
        return item

    def close_spider(self, spider):

        print('结束')


