# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy

class NewWakakaItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()

    # 公司id
    id = scrapy.Field()

    # 公司名称
    company_name = scrapy.Field()

    #股东名字
    shareholder = scrapy.Field()

    #股东类型
    share_type = scrapy.Field()

    #出资比例
    scale_money = scrapy.Field()

    #出资额度
    amount_money = scrapy.Field()

    #别的
    else_field = scrapy.Field()

    #别的2
    else_field2 = scrapy.Field()

    #名字
    name = scrapy.Field()

    #职位
    position = scrapy.Field()

    #公司简介
    company_introduce = scrapy.Field()

    # 主要经营产品
    main_project = scrapy.Field()

    # 营业执照号码
    business_num = scrapy.Field()

    # 发证机关
    send_office = scrapy.Field()

    # 核准日期
    check_date = scrapy.Field()

    # 经营状态
    run_status = scrapy.Field()

    # 成立时间
    set_date = scrapy.Field()

    # 职员人数
    num_people = scrapy.Field()    #不需要

    # 注册资本
    register_money = scrapy.Field()

    #注册资金的类型
    money_type = scrapy.Field()

    # 所属分类
    classify = scrapy.Field()

    # 所属地方
    #classify_city = scrapy.Field()

    # 类型
    type1 = scrapy.Field()

    # 顺企编码
    company_num = scrapy.Field()

    # 商铺
    shop = scrapy.Field()

    # 经营范围
    shop_range = scrapy.Field()

    # 经营模式
    shop_model = scrapy.Field()

    # 人气值
    fashion_num = scrapy.Field()




    #公司地址
    company_location = scrapy.Field()

    #固定电话
    call = scrapy.Field()

    #经理
    manager = scrapy.Field()

    #邮政编码
    postcode = scrapy.Field()

     #电子邮箱
    email_address = scrapy.Field()



    #所属公司
    entname = scrapy.Field()

    item_total = scrapy.Field()
    #变更事项
    #item = scrapy.Field()

    #变更前
    #after = scrap  y.Field()

    #变更后
    #before = scrapy.Field()

    #变更日期
    #date = scrapy.Field()

    #省
    province = scrapy.Field()

    #城市
    city = scrapy.Field()

    #区
    area = scrapy.Field()

    #经
    lng = scrapy.Field()

    #纬
    lat = scrapy.Field()