from new_wakaka.settings import USER_AGENTS as ua_list
import random


import psycopg2
import requests
import time
import re
import json
from multiprocessing.pool import ThreadPool   #线程池
import telnetlib
from new_wakaka.SQL_word import log

#更换 ip
class ProxyMiddleware():

    def __init__(self):
        l = log()
        
        conn = psycopg2.connect(database=l.database, user=l.user, password=l.password, host=l.host, port=l.port)
        cur = conn.cursor()
        self.ip_list = []
        cur.execute("select * from ippools")
        rows = cur.fetchall()

        for row in rows:
            a = 'http://' + row[0]
            self.ip_list.append(a)


    def process_request(self,request,spider):
        ip = random.choice(self.ip_list)      #随机选择一个ip
        request.meta['proxy'] = ip
        print("Operation done successfully",request.meta['proxy'])


#随机换user-agent
class UserAgentMiddleware(object):
    """
        给每一个请求随机切换一个User-Agent
    """
    def process_request(self, request, spider):
        user_agent = random.choice(ua_list)
        request.headers['User-Agent'] = user_agent



class Deal_content():

    def deal_time(self,date):
        if date:
            date = date.replace("年", "-").replace("月", "-").replace("日", "")
            return date
        else:
            date = None
        return date

    def deal_money(self,date):
        if date:
            date = ''.join(date)
            num = re.findall("\d*\.{0,1}\d*", date)
            if num:
                num = num[0]
            else:
                num = None
            if '美' in date:
                type_money = "美元"
                
            elif "人民" in date:
                type_money = "人民币"
                
            elif "日" in date:
                type_money = "日元"
                
            elif "港" in date:
                type_money = "港币"
                
            else:
                type_money = "人民币"
            return num, type_money

        else:
            return None, None

class Baidu_api():

    def getProxy(self,entName):
        header = {
            'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding':'gzip, deflate',
            'Accept-Language':'zh-CN,zh;q=0.9',
            'Cache-Control':'max-age=0',
            'Connection':'keep-alive',
            'Cookie':'BAIDUID=F1E00F657CA4A445AE2523B429C89D13:FG=1; BIDUPSID=F1E00F657CA4A445AE2523B429C89D13; PSTM=1534926749; PSINO=1; H_PS_PSSID=1461_27210_21103_26350_27111; BDORZ=B490B5EBF6F3CD402E515D22BCDA1598',
            'Host':'api.map.baidu.com',
            'Upgrade-Insecure-Requests':'1',
            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'
        }
        url = 'http://api.map.baidu.com/geocoder?address=%s&output=json&ak=U0QGae7viQsN0yLBirGsRD90XI0tlcGO' %entName

        res = requests.get(url, headers = header)
        js = res.json()
        result = js.get('result')
        if result:
            lng_1 = result.get('location').get('lng')
            lat = result.get('location').get('lat')
            print("lng_1, lat",lng_1, lat)
            return lng_1, lat
        else:
            return None, None


    def getAddress(self,lng_1,lat):

        url = 'https://apis.map.qq.com/jsapi?qt=rgeoc&lnglat=' + str(lng_1)  + '%2C' + str(lat) + '&key=FBOBZ-VODWU-C7SVF-B2BDI-UK3JE-YBFUS&output=jsonp&pf=jsapi&ref=jsapi&cb=qq.maps._svcb3.geocoder0'
        res = requests.get(url)
        data = re.sub('qq.maps._svcb3.geocoder0&&qq.maps._svcb3.geocoder0', '', res.text)
        data = data.lstrip('(')
        data = data.rstrip(')')
        jsondata = json.loads(data)
        if len(jsondata['detail']) != 0:
            if jsondata['detail']['poilist']:
                c = jsondata['detail']['poilist'][0]['addr_info']['c']
                p = jsondata['detail']['poilist'][0]['addr_info']['p']
                d = jsondata['detail']['poilist'][0]['addr_info']['d']

                if c == '':
                    i = 1
                    while True:
                        c = jsondata['detail']['poilist'][i]['addr_info']['c']
                        p = jsondata['detail']['poilist'][i]['addr_info']['p']
                        d = jsondata['detail']['poilist'][i]['addr_info']['d']
                        if c != '':
                            break
                        else:
                            i = i + 1
                return p, c, d
            else:
                c = jsondata['detail']['results'][0]['c']
                p = jsondata['detail']['results'][0]['p']
                d = jsondata['detail']['results'][0]['d']
                return p, c, d






