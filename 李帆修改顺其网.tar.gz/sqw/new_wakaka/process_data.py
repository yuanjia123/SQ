import re

def deta_revision(item):
    item_my = dict(item)
    # 去掉字段的空字符  用-表示
    for it in item_my.keys():
        if str(item_my[it]) == '[]':
            item_my[it] = '-'
        item_my[it] = str(item_my[it]).replace("[", '')
        item_my[it] = str(str(item_my[it]).replace("]", ''))
        item_my[it] = str(str(item_my[it]).replace("{", ''))
        item_my[it] = str(str(item_my[it]).replace("}", ''))

    for it in item_my.keys():
        if str(item_my[it]) == '[]':
            item_my[it] = '-'
        # str(item_my[it]).replace("[",'')
        # str(item_my[it]).replace("]", '')
        # str(item_my[it]).replace("{", '')
        # str(item_my[it]).replace("}", '')

    # a = {"company_name": "连云港陆刘邓石英玻璃泡壳制造厂", "main_project": ["我有大量石英泡壳 , ", " , 价格廉。需要可以面谈！18762726462\r\n陆刘邓\r\n616510864@qq.com "], "type1": [], "run_status": ["在业"], "shop_range": ["我有大量石英泡壳 , ", " , 价格廉。需要可以面谈！18762726462\r\n陆刘邓\r\n616510864@qq.com "], "set_date": ["2010年03月10日"], "shop": [], "business_num": [], "check_date": [], "register_money": ["30 (万元)"], "classify": ["玻璃公司"], "num_people": ["10人"], "send_office": [], "company_num": ["1983"], "shop_model": [], "classify_city": [], "fashion_num": []}
    # dict_a = dict(item)
    #
    # for it in dict_a.keys():
    #     if str(dict_a[it]) == '[]':
    #         dict_a[it] = '-'
    #
    # item_my = dict(item)

    # >> > s2 = '住宅备案均价：9048元/ M'
    # >> > re.findall("\d{4,5}[\u4e00-\u9fa5]", s2)
    #print(dict_a['shop_range'])
    #dict_a['shop_range'] = re.findall("[\u4e00-\u9fa5]", dict_a['shop_range'])

    # for i in dict_a['shop_range']:
    #     a = i.replace(" ","")
    #     b = i.replace("\r", "")
    #     c = i.replace("\n", "")
    #     d = i.replace(",", "")
    #
    #     n = a + b + c + d
    # print(n)

    #print(dict_a['shop_range'])
#deta_revision()