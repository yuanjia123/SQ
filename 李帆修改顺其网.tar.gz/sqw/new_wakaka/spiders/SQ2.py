﻿# -*- coding: utf-8 -*-
import scrapy
from new_wakaka.items import NewWakakaItem
import requests
import re
import time
import psycopg2
from new_wakaka.SQL_word import log
from new_wakaka.middlewares import Deal_content

from new_wakaka.middlewares import Baidu_api

def connect():
    l = log()
    conn = psycopg2.connect(database=l.database, user=l.user, password=l.password, host=l.host, port=l.port)
    cur =conn.cursor()
    cur.execute("select max(sq_code) from bjzs_big_data.baoji_company")
    rows = cur.fetchall()
    open = rows[0][0]
    return open

class Sq2Spider(scrapy.Spider):
    name = 'SQ2'
    allowed_domains = ['11467.com']
    #open = connect()
    # last = open*2
    # print("********************从这个数字开始**********", open)
    # print('*****************到这里结束*************',last)

    #start_urls = ['http://www.11467.com/qiye/%s.htm'  % x for x in range(open,last)]

    start_urls = ['http://www.11467.com/qiye/%s.htm'  % x for x in range(100,10000)]

    def parse(self,response):
        print('============response.status==============', response.status)
        if response.status == 404:
            print('===========response.statusresponse.statusresponse.status===============')
            print(response.text)
            # return

        item = NewWakakaItem()
        deal = Deal_content()


        '''
         #股东名字
        shareholder = scrapy.Field()

        #类型
        share_type = scrapy.Field()

        #出资比例
        scale_money = scrapy.Field()

        #出资额度
        amount_money = scrapy.Field()

        '''

        li_money = []

        if response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[2]//text()').extract():
            li_money.append(response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[2]//text()').extract())
        if response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[3]//text()').extract():
            li_money.append(response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[3]//text()').extract())
        if response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[4]//text()').extract():
            li_money.append(response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[4]//text()').extract())

        if li_money == '':
            item['else_field2'] = ''
        else:
            item['else_field2'] = li_money


        #主要领导人
        li = []
        if response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[2]//text()').extract():
            li.append(response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[2]//text()').extract())

        if response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[3]//text()').extract():
            li.append(response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[3]//text()').extract())

        if response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[4]//text()').extract():
            li.append(response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[4]//text()').extract())


        item['else_field'] = li


        #公司简介
        item['company_introduce'] = None
        if response.xpath("//div[@id='aboutuscontent']//text()").extract_first():
            item['company_introduce'] = response.xpath("//div[@id=\'aboutuscontent\']//text()").extract_first()

        #单位地址
        item['company_location'] = None
        if response.xpath("//dl[@class=\"codl\"]//dd[1]/text()").extract_first():
            item['company_location'] = response.xpath("//dl[@class=\"codl\"]//dd[1]/text()").extract_first()

        #固定电话
        item['call'] = []
        if response.xpath("//dl[@class=\"codl\"]//dd[2]/text()").extract():
            item['call'] = response.xpath("//dl[@class=\"codl\"]//dd[2]/text()").extract()
        elif response.xpath("//dl[@class='codl']//dt[starts-with(text(),\"固定电话：\")]/following-sibling::dd[1]//text()").extract():
            item['call'] = response.xpath("//dl[@class='codl']//dt[starts-with(text(),\"固定电话：\")]/following-sibling::dd[1]//text()").extract()

        #经理
        item['manager'] = None
        if response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"经理：\")]/following-sibling::dd[1]//text()").extract_first():
            item['manager'] = response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"经理：\")]/following-sibling::dd[1]//text()").extract_first()
        elif  response.xpath("//dl[@class=\"codl\"]//dd[3]/text()").extract_first():
            item['manager'] = response.xpath('//dl[@class=\"codl\"]//dd[3]/text()').extract_first()

        #电子邮箱
        item['email_address'] = []
        if response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"电子邮件：\")]/following-sibling::dd[1]//text()").extract():
            item['email_address'] = response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"电子邮件：\")]/following-sibling::dd[1]//text()").extract()
        elif response.xpath("//dl[@class=\"codl\"]//dd[5]/text()").extract():
            item['email_address'] = response.xpath("//dl[@class=\"codl\"]//dd[5]/text()").extract()

        # # 邮政编码
        # item['postcode'] = None
        # if response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"邮政编码：\")]/following-sibling::dd[1]//text()").extract_first():
        #     item['postcode'] = response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"邮政编码：\")]/following-sibling::dd[1]//text()").extract_first()

        # elif response.xpath("//dl[@class=\"codl\"]//dd[7]/text()").extract_first():
        #     item['postcode'] = response.xpath("//dl[@class=\"codl\"]//dd[7]/text()").extract_first()

        # 法人名称
        lng_1 =  None
        lat = None
        item['company_name'] = None
        if response.xpath('//td[starts-with(text(),"法人名称：")]/following-sibling::td/text()').extract_first():
            item['company_name'] = response.xpath(
            '//td[starts-with(text(),"法人名称：")]/following-sibling::td/text()').extract_first()

            bai = Baidu_api()

            #调用函数返回坐标
            lng_1, lat = bai.getProxy(item['company_name'])

            #如果坐标存在  救治向下面语句， 显示他在哪个省。 哪个地方。
            if lng_1:
                p,c,d = bai.getAddress(lng_1, lat)
                if c == "上海市" or c == "重庆市" or c == '天津市' or c == '北京市':
                    c = c + "市辖区"
            else:
                c = None
                p = None
                d = None
            # 省
            item['province'] = p

            # 城市
            item['city'] = c

            # 区
            item['area'] = d

            # 经
            item['lng'] = lng_1

            # 纬
            item['lat'] = lat

        #------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        #主要经营产品
        item['main_project'] = None
        if response.xpath('//td[starts-with(text(),"主要经营产品：")]/following-sibling::td//text()').extract():
            item['main_project'] = response.xpath('//td[starts-with(text(),"主要经营产品：")]/following-sibling::td//text()').extract()
        elif response.xpath('//td[starts-with(text(),"经营产品：")]/following-sibling::td//text()').extract():
            item['main_project'] = response.xpath('//td[starts-with(text(),"主要经营产品：")]/following-sibling::td//text()').extract()
        
        if item['main_project']:
            item['main_project'] = ''.join(item['main_project'])


        # 经营范围 or 主要经营范围
        item['shop_range'] = None
        if response.xpath('//td[starts-with(text(),"主要经营范围")]/following-sibling::td//text()').extract():
            item['shop_range'] = response.xpath('//td[starts-with(text(),"主要经营范围")]/following-sibling::td//text()').extract()

        elif response.xpath('//td[starts-with(text(),"经营范围：")]/following-sibling::td//text()').extract():
            item['shop_range'] = response.xpath('//td[starts-with(text(),"经营范围：")]/following-sibling::td//text()').extract()
        
        if item['shop_range']:
            item['shop_range'] = ''.join(item['shop_range'])



        # 经营状态
        item['run_status'] = None
        if response.xpath('//td[starts-with(text(),"经营状态：")]/following-sibling::td/text()').extract_first():
            item['run_status'] = response.xpath('//td[starts-with(text(),"经营状态：")]/following-sibling::td/text()').extract_first()


        # # 经营模式
        # item['shop_model'] = None
        # if response.xpath('//td[starts-with(text(),"经营模式：")]/following-sibling::td/text()').extract():
        #     item['shop_model'] = response.xpath('//td[starts-with(text(),"经营模式：")]/following-sibling::td/text()').extract()


        # 成立时间
        item['set_date'] = None
        if response.xpath('.//td[contains(text(), "成立时间")]/following-sibling::td/text()').extract_first():
            item['set_date'] = response.xpath('.//td[contains(text(), "成立时间")]/following-sibling::td/text()').extract_first()
        elif response.xpath('//td[starts-with(text(),"成立时间：")]/following-sibling::td/text()').extract_first():
            item['set_date'] = response.xpath('//td[starts-with(text(),"成立时间：")]/following-sibling::td/text()').extract_first()

        #处理时间
        item['set_date'] = deal.deal_time(item['set_date'])


        # # 职员人数
        # item['num_people'] = None
        # if response.xpath(
        #     '//td[starts-with(text(),"职员人数：")]/following-sibling::td/text()').extract():
        #     item['num_people'] = response.xpath(
        #     '//td[starts-with(text(),"职员人数：")]/following-sibling::td/text()').extract()


        # 注册资本
        item['register_money'] = None
        item['money_type'] = None
        if response.xpath('//td[starts-with(text(),"注册资本：")]/following-sibling::td/text()').extract():
            item['register_money'] = response.xpath('//td[starts-with(text(),"注册资本：")]/following-sibling::td/text()').extract()

            #处理注册资金， 分成两个字段。
            item['register_money'],item['money_type'] = deal.deal_money(item['register_money'])


        # # 人气值
        # item['fashion_num'] = None
        # if response.xpath(
        #     '//td[starts-with(text(),"人气值：")]/following-sibling::td/text()').extract():
        #     item['fashion_num'] = response.xpath(
        #     '//td[starts-with(text(),"人气值：")]/following-sibling::td/text()').extract()


        # 顺企编码：
        item['company_num'] = None
        if response.xpath('//td[starts-with(text(),"顺企编码：")]/following-sibling::td/text()').extract_first():
            item['company_num'] = response.xpath('//td[starts-with(text(),"顺企编码：")]/following-sibling::td/text()').extract_first()

        # # 商铺
        # item['shop'] = None
        # if response.xpath(
        #     '//td[starts-with(text(),"商铺：")]/following-sibling::td/a/@href').extract():
        #     item['shop'] = response.xpath(
        #     '//td[starts-with(text(),"商铺：")]/following-sibling::td/a/@href').extract()

        # 营业执照号码
        item['business_num'] = None
        if response.xpath('//td[starts-with(text(),"营业执照号码")]/following-sibling::td/text()').extract_first():
            item['business_num'] = response.xpath('//td[starts-with(text(),"营业执照号码")]/following-sibling::td/text()').extract_first()

        # 发证机关
        item['send_office'] = None
        if response.xpath('//td[starts-with(text(),"发证机关")]/following-sibling::td/text()').extract_first():
            item['send_office'] = response.xpath('//td[starts-with(text(),"发证机关")]/following-sibling::td/text()').extract_first()


        # 核准日期
        item['check_date'] = None
        if response.xpath('//td[starts-with(text(),"核准日期：")]/following-sibling::td/text()').extract_first():
            item['check_date'] = response.xpath('//td[starts-with(text(),"核准日期：")]/following-sibling::td/text()').extract_first()
            item['check_date'] = deal.deal_time(item['check_date'])



        # 经营状态
        item['run_status'] = None
        if response.xpath('//td[starts-with(text(),"经营状态：")]/following-sibling::td/text()').extract_first():
            item['run_status'] = response.xpath('//td[starts-with(text(),"经营状态：")]/following-sibling::td/text()').extract_first()


        # # 所属分类：
        # item['classify'] = None
        # if response.xpath('//td[starts-with(text(),"所属分类：")]/following-sibling::td//text()').extract():
        #     item['classify'] = response.xpath('//td[starts-with(text(),"所属分类：")]/following-sibling::td//text()').extract()



        # 类型
        item['type1'] = None
        if response.xpath('//td[starts-with(text(),"类型：")]/following-sibling::td/text()').extract_first():
            item['type1'] = response.xpath('//td[starts-with(text(),"类型：")]/following-sibling::td/text()').extract_first()

        # 所属公司
        item['entname'] = None
        if response.xpath("//div[@id='biangeng']/h4[@class='boxtitle']/text()").extract_first():
            item['entname'] = response.xpath("//div[@id='biangeng']/h4[@class='boxtitle']/text()").extract_first()


        #变更事项总共
        '''
            原因：
                请求一次页面， 可以拿到多次的， 公司变更。
                可是item 设定的机制却是一次只能， 记录一次数据，返回出去给item pipline
            
            所以：
                把多次的历史变更， 放到一个list里面。返回给item pipline 然后在 item pipline 里面进行整理， 然后进行存储。
          '''
        li = []
        infos2 = response.xpath(".//div[@id='biangeng']/div/table//tr[2]//td//text()").extract()
        if response.xpath(".//div[@id='biangeng']/div/table//tr[2]//td//text()").extract():
            li.append(infos2)

        infos3 = response.xpath(".//div[@id='biangeng']/div/table//tr[3]//td//text()").extract()
        if response.xpath(".//div[@id='biangeng']/div/table//tr[3]//td//text()").extract():
            li.append(infos3)

        infos4 = response.xpath(".//div[@id='biangeng']/div/table//tr[4]//td//text()").extract()
        if response.xpath(".//div[@id='biangeng']/div/table//tr[4]//td//text()").extract():
            li.append(infos4)

        infos5 = response.xpath(".//div[@id='biangeng']/div/table//tr[5]//td//text()").extract()
        if response.xpath(".//div[@id='biangeng']/div/table//tr[5]//td//text()").extract():
            li.append(infos5)

        item['item_total'] = None
        if li:
            item['item_total'] = li

        yield item