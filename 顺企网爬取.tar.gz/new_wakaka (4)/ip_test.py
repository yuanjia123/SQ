import psycopg2
import requests
import time
from multiprocessing.pool import ThreadPool   #线程池
import telnetlib
class Net():
    def __init__(self):
        self.conn = psycopg2.connect(database="postgres", user="postgres", password="123456", host="127.0.0.1",port="5432")
        self.success_ip = []

    def B(self):
        cur = self.conn.cursor()
        cur.execute("select * from ippools")
        rows = cur.fetchall()
        for row in rows:
            a = 'http://' + row[0]
            #print("ip",a)
            self.Test_ip(a)
        # print("Operation done successfully")
        # request.meta['proxy'] = '


    def Test_ip(self,text_ip):
        try:
            requests.get('http://wenshu.court.gov.cn/', proxies={"http": text_ip})  # 这个地方也可以写res.status_code == 200: 作为判断
        except:
            failed_ip = text_ip
            print('代理链接失败connect failed', failed_ip)

        else:
            success_ip = text_ip
            self.success_ip.append(success_ip)
            print('代理成功success', success_ip)


if __name__ == '__main__':
    while True:
        pool = ThreadPool(16)  # 实现一个线程池 ，参数是线程的数量, 这里就是两个线程等待调用
        n = Net()
        n.B()
        pool.apply_async(n.B())  # 这个线程池传参很精髓
        pool.close()  # 关闭线程池， 不在提交任务，
        pool.join()  # 等待线程池里面的任务 运行完毕
        time.sleep(180)


