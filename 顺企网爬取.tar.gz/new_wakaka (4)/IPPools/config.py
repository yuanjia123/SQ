# coding=utf-8

database = "postgres"
user="postgres"
password="123456"
host='127.0.0.1'
port="5432"

