# coding=utf-8

from lxml import etree
from bs4 import BeautifulSoup
import logging
import requests
import time
import json
import random

from threading import Thread
from threading import Lock
from queue import Queue

from outDB import outDB

class IPPools(object):

    def __init__(self):
        self.od = outDB()
        self.header = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36'
            }
        self.ip_queue = Queue()
    # #代理IP池（花钱）
    # def buildIPPools(self):
    #     response = requests.get('http://piping.mogumiao.com/proxy/api/get_ip_al?appKey=44486bb8b80c463c9dee3e92829c5a34&count=5&expiryDate=0&format=1&newLine=2')
    #     jsondatas = json.loads(response.text)

    #     ipdatas = []
    #     for data in jsondatas['msg']:
    #         print(data)
    #         string = data['ip'] + ':' + data['port']
    #         ipdatas.append(string)
    #     return ipdatas
    #     # file = open('ip.txt','a',encoding='utf-8')
    #     # file.write(repr(ipdatas))
    #     # file.close()

    # #爬出免费代理IP 西刺
    # def crawlXiCi(self, ableIPdatas):
    #     ipdatas = []
    #     print(ableIPdatas)
    #     response = requests.get('http://www.xicidaili.com/nn/',headers = self.header,proxies={'http': random.choice(ableIPdatas), 'https': random.choice(ableIPdatas)})

    #     selector = etree.HTML(response.text)
    #     ip = selector.xpath('.//table[@id="ip_list"]/tr/td[2]/text()')
    #     port = selector.xpath('.//table[@id="ip_list"]/tr/td[3]/text()')
    #     ipdatas = []
    #     for i in range(0,len(ip)):
    #         ipdata = ip[i] + ':' + port[i]
    #         ipdatas.append(ipdata)
    #     return ipdatas

    #处理无忧网的端口加密
    def getTruePort(self, string):
        lists = ['A','B','C','D','E','F','G','H','I','Z']
        str_ = ''
        for s in string:
            l = lists.index(s)
            str_ = str_ + str(l)
        return str(int(int(str_)/8))

    #无忧
    def crawlWuYouIndex(self):
        
        urls = ['http://www.data5u.com/','http://www.data5u.com/free/gngn/index.shtml','http://www.data5u.com/free/gnpt/index.shtml']
        for url in urls:
            response = requests.get(url,headers = self.header)
            selector = etree.HTML(response.text)
            ip = selector.xpath('.//ul[@class="l2"]/span[1]/li/text()')
            port = selector.xpath('.//ul[@class="l2"]/span[2]/li/@class')
            for i in range(0,len(ip)):
                falsePort = port[i][5:]
                string = ip[i]+':'+ self.getTruePort(falsePort)
                self.ip_queue.put(string)
            time.sleep(1)

    def crawlWuYou(self, findType, findLists):
        
        for li in findLists:
            print('1')
            url = 'http://www.data5u.com/free/%s' %findType + '/%s/index.html' %li
            response = requests.get(url,headers=self.header)
            selector = etree.HTML(response.text)
            ip = selector.xpath('.//ul[@class="l2"]/span[1]/li/text()')
            port = selector.xpath('.//ul[@class="l2"]/span[2]/li/@class')           
            for i in range(0,len(ip)):
                falsePort = port[i][5:]
                string = ip[i]+':'+ self.getTruePort(falsePort)

                self.ip_queue.put(string)        
            time.sleep(1)

    def getCity(self):
        response = requests.get('http://www.data5u.com/free/index.html',headers = self.header)
        selector = etree.HTML(response.text)
        cities = selector.xpath('.//div[@class = "problem"][2]//span/@title')
        return cities

    def crawlkuaidaili(self):
        response = requests.get('https://www.kuaidaili.com/free/inha/1/',headers = self.header)
        selector = etree.HTML(response.text)
        ip = selector.xpath('.//td[@data-title="IP"]/text()')
        port = selector.xpath('.//td[@data-title="PORT"]/text()')
        print(ip)
        ipdatas = []
        for i in range(0,len(ip)):
            string = ip[i]+':'+ port[i]
            self.ip_queue.put(string)

    # def crwalxdaili(self):
    #     response = requests.get('http://www.ip181.com/',headers=self.header)
    #     jsondatas = json.loads(response.text)
    #     ipdatas = []
    #     for data in jsondatas['RESULT']:
    #         string = data['ip'] + ':' + data['port']
    #         ipdatas.append(string)
    #     return ipdatas

    def testIP(self):
        print('1')
        while True: 
            try:
                ipdata = self.ip_queue.get(True,1)
                response = requests.get('http://www.jd.com/', headers = self.header, proxies = {'http': ipdata,'https': ipdata}, timeout=0.5)
                self.od.writeIP(ipdata)
            #尝试失效的异常处理
            except requests.exceptions.ConnectionError:
                pass
            except requests.exceptions.ReadTimeout:
                pass
            except:
                self.ip_queue.task_done()
                break
    

    def run(self):
        ports = ['8080','80','8888','6666','3128','8060']
        cities = self.getCity()
        self.crawlWuYou('port',ports)
        print('1')
        self.crawlWuYouIndex()
        print('2')
        self.crawlWuYou('area',cities)
        print('3')
        
        thread_1=Thread(target=self.testIP)
        thread_2=Thread(target=self.testIP)
        thread_3=Thread(target=self.testIP)
        thread_4=Thread(target=self.testIP)
        thread_1.start()
        thread_2.start()
        thread_3.start()    
        thread_4.start()
        thread_1.join()
        thread_2.join()
        thread_3.join()
        thread_4.join()
    
if __name__ == '__main__':
    p = IPPools()

    while True:
        print('开始')
        p.run()
        print('结束')
        time.sleep(180)
    