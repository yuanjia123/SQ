import psycopg2
import config

class outDB(object):

    #C02SP70YGF1J,47.92.116.107
    def writeIP(self,IP):
        conn = psycopg2.connect(database=config.database, user=config.user, password=config.password, host=config.host, port=config.port)
        try:
            cur=conn.cursor()
            try:
                cur.execute("""INSERT INTO ippools values(%s) ;""",(IP,))
            except Exception as err:
                print('插入出错: ',err)
            conn.commit()
        finally:
            if cur:
                cur.close()
        conn.close()

    def readIP(self):
        conn = psycopg2.connect(database=config.database, user=config.user, password=config.password, host=config.host, port=config.port)
        try:
            cur=conn.cursor()
            try:
                cur.execute('select ip from ippools')
                ips = cur.fetchall()
                if len(ips)!=0:
                    return ips
            except Exception as err:
                print('读取出错: ',err)
            conn.commit()
        finally:
            if cur:
                cur.close()
        conn.close()   

    def deleteIP(self,IP):
        conn = psycopg2.connect(database=config.database, user=config.user, password=config.password, host=config.host, port=config.port)
        try:
            cur=conn.cursor()
            try:
                cur.execute("""delete from ippools where ip = %s ;""",(IP,))
            except Exception as err:
                print('删除出错: ',err)
            conn.commit()
        finally:
            if cur:
                cur.close()
        conn.close()

