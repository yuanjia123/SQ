from ip_test.Net import success_ip as su
print(su)