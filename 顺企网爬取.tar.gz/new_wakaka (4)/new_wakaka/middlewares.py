from new_wakaka.settings import USER_AGENTS as ua_list
import random


import psycopg2
import requests
import time
from multiprocessing.pool import ThreadPool   #线程池
import telnetlib


#更换 ip
class ProxyMiddleware():

    def __init__(self):
        conn = psycopg2.connect(database="postgres", user="postgres", password="123456", host="127.0.0.1", port="5432")
        cur = conn.cursor()
        self.ip_list = []
        cur.execute("select * from ippools")
        rows = cur.fetchall()

        for row in rows:
            #print("/////",row)
            a = 'http://' + row[0]
            self.ip_list.append(a)
            # print("*****",a)
            # print("*****", type(a))

    def process_request(self,request,spider):
        ip = random.choice(self.ip_list)
        request.meta['proxy'] = ip
        print("Operation done successfully",request.meta['proxy'])


#随机换user-agent
class UserAgentMiddleware(object):
    """
        给每一个请求随机切换一个User-Agent
    """
    def process_request(self, request, spider):
        user_agent = random.choice(ua_list)
        request.headers['User-Agent'] = user_agent



