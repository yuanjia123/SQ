# -*- coding: utf-8 -*-
# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import psycopg2
import json
import re
class NewWakakaPipeline(object):
    def open_spider(self, spider):
        self.file = open("SQ2.json", "w", encoding="utf-8")

    def process_item(self, item, spider):
        content = json.dumps(dict(item), ensure_ascii=False) + "\n"
        #self.file.write(content)
        return item

    def close_spider(self, spider):
        self.file.close()

class SqlPipline(object):
    def open_spider(self, spider):
        self.conn = psycopg2.connect(database="postgres", user="postgres", password="123456", host="127.0.0.1",port="5432")


    def process_item(self, item, spider):

        # 产生一个游标
        self.cur = self.conn.cursor()
        item_my = dict(item)

        # 给空的字段添加 -
        for it in item_my.keys():
            if str(item_my.get(it)) == '[]':
                item_my[it] = '-'


        #主要领导人
        try:
            if item_my.get('else_field'):
                t_l = item_my.get('else_field')
                for l in t_l:
                    self.cur.execute(
                    "INSERT INTO bjzs_big_data.baoji_company_manager (name_1,position_1) VALUES (%s,%s)", (l[0], l[1]))

        except:
            pass


        try:
            if item_my.get('else_field2'):
                t_l_2 = item_my.get('else_field2')
                for j in t_l_2:
                    self.cur.execute(
                    "INSERT INTO bjzs_big_data.baoji_company_holdercount (holder,proportion,money) VALUES (%s,%s,%s)",
                    (j[0], j[2], j[3]))
        except:
            pass



        change_item = {}
        try:
            for i in item_my['item_total']:  # 拿到股权的list 循环赋值。

                if i:                        # 如果 i存在
                    try:
                        if i[0]:
                            change_item['item_1'] = i[0]
                        else:
                            change_item['item_1'] = '-'

                        if i[1]:
                            change_item['after'] = i[1]
                        else:
                            change_item['after'] = '-'

                        if i[2]:
                            change_item['before'] = i[2]
                        else:
                            change_item['before'] = '-'

                        if i[3]:
                            change_item['date'] = i[3]
                        else:
                            change_item['date'] = ''
                    except IndexError as e:
                        print("某一个字段没有",e)

                    # 公司股权变更存储
                    if not item_my.get('entname'):
                        item_my['entname'] = '-'



                    try:
                            self.cur.execute("INSERT INTO bjzs_big_data.baoji_company_change (entname,item,after,before,date_time) VALUES (%s,%s,%s,%s,%s)", (
                            item_my['entname'], change_item['item_1'], change_item['after'], change_item['before'],
                            change_item['date']))
                    except KeyError as k:
                        print("某一个字段没有", k)
        except:
            pass


        #去掉字段的空字符  用-表示
        for it in item_my.keys():
            if str(item_my[it]) == '[]':
                item_my[it] = '-'
            item_my[it] = str(item_my[it]).replace("['",'')
            item_my[it] = str(item_my[it]).replace("']", '')
            item_my[it] = str(item_my[it]).replace("[]", '')
            item_my[it] = str(item_my[it]).replace("{", '')
            item_my[it] = str(item_my[it]).replace("}", '')
            item_my[it] = str(item_my[it]).replace("\\r", '')
            item_my[it] = str(item_my[it]).replace("\\n", '')

        #顺企网工商信息和基本资料存储、位置、以及公司详情
        if item_my.get('email_address') == '':
            item_my['email_address'] = '-'

        try:
            self.cur.execute(
                "INSERT INTO bjzs_big_data.baoji_company (entname,main_project,uniform_credit_code,r_a,verify_date,business_status,open_date,regist_money,business_type,sq_code,business_scope,address,phone,legal_person,email,introduction) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                (item_my['company_name'], item_my['main_project'], item_my['business_num'], item_my['send_office'],item_my['check_date'],
                 item_my['run_status'], item_my['set_date'], item_my['register_money'], item_my['type1'],item_my['company_num'],
                 item_my['shop_range'],item_my['company_location'],item_my['call'],item_my['manager'],item_my['email_address'],
                 item_my['company_introduce']))
        except :
            print("链接有问题,")
        #提交
        self.conn.commit()

        #关闭游标
        self.cur.close()

        #给引擎返回数据
        return item

    def close_spider(self, spider):

        self.conn.close()

