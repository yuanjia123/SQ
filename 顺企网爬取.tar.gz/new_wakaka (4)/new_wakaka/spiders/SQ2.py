# -*- coding: utf-8 -*-
import scrapy
from new_wakaka.items import NewWakakaItem
import requests
import re
import time
import psycopg2

def connect():
    conn = psycopg2.connect(database="postgres", user="postgres", password="123456", host="127.0.0.1", port="5432")
    cur =conn.cursor()

    cur.execute("select max(sq_code) from bjzs_big_data.baoji_company")
    rows = cur.fetchall()
    open = rows[0][0]
    return open
class Sq2Spider(scrapy.Spider):
    name = 'SQ2'
    allowed_domains = ['11467.com']
    open = connect()
    last = open*2
    print("********************从这个数字开始**********", open)
    print('*****************到这里结束*************',last)

    start_urls = ['http://www.11467.com/qiye/%s.htm'  % x for x in range(open,last)]
    #start_urls = ['http://www.11467.com/qiye/45429418.htm']
    base_url = 'http://www.11467.com/'


    def parse(self,response):

        if response.status == 404:
            print("no",response.url)
            return

        item = NewWakakaItem()


        '''
         #股东名字
    shareholder = scrapy.Field()

    #类型
    share_type = scrapy.Field()

    #出资比例
    scale_money = scrapy.Field()

    #出资额度
    amount_money = scrapy.Field()

        '''

        li_money = []

        if response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[2]//text()').extract():
            li_money.append(response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[2]//text()').extract())
        if response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[3]//text()').extract():
            li_money.append(response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[3]//text()').extract())
        if response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[4]//text()').extract():
            li_money.append(response.xpath('//div[@id="gudong"]/div[@class=\'boxcontent\']//tr[4]//text()').extract())

        if li_money == '':
            item['else_field2'] = ''
        else:
            item['else_field2'] = li_money


        #print(":::::::li_money::::::::",li_money)


        #主要领导人
        li = []
        if response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[2]//text()').extract():
            li.append(response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[2]//text()').extract())

        if response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[3]//text()').extract():
            li.append(response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[3]//text()').extract())

        if response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[4]//text()').extract():
            li.append(response.xpath('//div[@id="zhiyuan"]/div[@class=\'boxcontent\']//tr[4]//text()').extract())


        item['else_field'] = li


        #公司简介
        item['company_introduce'] = None
        if response.xpath("//div[@id='aboutuscontent']//text()").extract_first():
            item['company_introduce'] = response.xpath("//div[@id=\'aboutuscontent\']//text()").extract_first()


        #单位地址
        item['company_location'] = None
        if response.xpath("//dl[@class=\"codl\"]//dd[1]/text()").extract_first():
            item['company_location'] = response.xpath("//dl[@class=\"codl\"]//dd[1]/text()").extract_first()

        #固定电话
        item['call'] = None
        if response.xpath("//dl[@class=\"codl\"]//dd[2]/text()").extract_first():
            item['call'] = response.xpath("//dl[@class=\"codl\"]//dd[2]/text()").extract_first()
        elif response.xpath("//dl[@class='codl']//dt[starts-with(text(),\"固定电话：\")]/following-sibling::dd[1]//text()").extract_first():
            item['call'] = response.xpath("//dl[@class='codl']//dt[starts-with(text(),\"固定电话：\")]/following-sibling::dd[1]//text()").extract_first()

        #经理
        item['manager'] = None
        if response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"经理：\")]/following-sibling::dd[1]//text()").extract_first():
            item['manager'] = response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"经理：\")]/following-sibling::dd[1]//text()").extract_first()
        elif  response.xpath("//dl[@class=\"codl\"]//dd[3]/text()").extract_first():
            item['manager'] = response.xpath('//dl[@class=\"codl\"]//dd[3]/text()').extract_first()

        # 电子邮箱
        item['email_address'] = None
        if response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"电子邮件：\")]/following-sibling::dd[1]//text()").extract_first():
            item['email_address'] = response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"电子邮件：\")]/following-sibling::dd[1]//text()").extract_first()

        elif response.xpath("//dl[@class=\"codl\"]//dd[5]/text()").extract_first():
            item['email_address'] = response.xpath("//dl[@class=\"codl\"]//dd[5]/text()").extract_first()


        # 邮政编码
        item['postcode'] = None
        if response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"邮政编码：\")]/following-sibling::dd[1]//text()").extract_first():
            item['postcode'] = response.xpath("//dl[@class=\'codl\']//dt[starts-with(text(),\"邮政编码：\")]/following-sibling::dd[1]//text()").extract_first()

        elif response.xpath("//dl[@class=\"codl\"]//dd[7]/text()").extract_first():
            item['postcode'] = response.xpath("//dl[@class=\"codl\"]//dd[7]/text()").extract_first()

        # 法人名称
        item['company_name'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"法人名称：")]/following-sibling::td/text()').extract_first():
            item['company_name'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"法人名称：")]/following-sibling::td/text()').extract_first()

        try:
            a = response.xpath(
                '//table[@class=\'codl\']//td[starts-with(text(),"主要经营产品：")]/following-sibling::td//text()').extract()
            b = response.xpath(
                '//table[@class=\'codl\']//td[starts-with(text(),"经营产品：")]/following-sibling::td//text()').extract()
           #print("******-------------*************9999999999%s,%s",type(a),type(b))

            #主要经营产品
            item['main_project'] = str(a) + str(b)
        except:
            pass


        # 经营范围 or 主要经营范围
        item['shop_range'] = None
        if response.xpath('//table[@class=\'codl\']//td[starts-with(text(),"主要经营产品：")]/following-sibling::td//text()').extract():
            item['shop_range'] = response.xpath('//table[@class=\'codl\']//td[starts-with(text(),"主要经营产品：")]/following-sibling::td//text()').extract()

        elif response.xpath('//table[@class=\'codl\']//td[starts-with(text(),"经营范围：")]/following-sibling::td//text()').extract():
            item['shop_range'] = response.xpath('//table[@class=\'codl\']//td[starts-with(text(),"经营范围：")]/following-sibling::td//text()').extract()




        # 经营状态
        item['run_status'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"经营状态：")]/following-sibling::td/text()').extract_first():
            item['run_status'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"经营状态：")]/following-sibling::td/text()').extract_first()


        # 经营模式
        item['shop_model'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"经营模式：")]/following-sibling::td/text()').extract():
            item['shop_model'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"经营模式：")]/following-sibling::td/text()').extract()


        # 成立时间
        item['set_date'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"成立时间：")]/following-sibling::td/text()').extract():
            item['set_date'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"成立时间：")]/following-sibling::td/text()').extract()



        # 职员人数
        item['num_people'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"职员人数：")]/following-sibling::td/text()').extract():
            item['num_people'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"职员人数：")]/following-sibling::td/text()').extract()


        # 注册资本
        item['register_money'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"注册资本：")]/following-sibling::td/text()').extract():
            item['register_money'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"注册资本：")]/following-sibling::td/text()').extract()
            print("*****************item['register_money']***************",item['register_money'])
            item['register_money'] = re.findall('\d{1,9}', item['register_money'][0])[0]



        # 人气值
        item['fashion_num'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"人气值：")]/following-sibling::td/text()').extract():
            item['fashion_num'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"人气值：")]/following-sibling::td/text()').extract()


        # 顺企编码：
        item['company_num'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"顺企编码：")]/following-sibling::td/text()').extract():
            item['company_num'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"顺企编码：")]/following-sibling::td/text()').extract()

        # 商铺
        item['shop'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"商铺：")]/following-sibling::td/a/@href').extract():
            item['shop'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"商铺：")]/following-sibling::td/a/@href').extract()

        # 营业执照号码
        item['business_num'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"营业执照号码")]/following-sibling::td/text()').extract():
            item['business_num'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"营业执照号码")]/following-sibling::td/text()').extract()

        # 发证机关
        item['send_office'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"发证机关")]/following-sibling::td/text()').extract():
            item['send_office'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"发证机关")]/following-sibling::td/text()').extract()


        # 核准日期
        item['check_date'] = None
        if response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"核准日期：")]/following-sibling::td/text()').extract():
            item['check_date'] = response.xpath('//table[@class=\'codl\']//td[starts-with(text(),"核准日期：")]/following-sibling::td/text()').extract()



        # 经营状态
        item['run_status'] = None
        if response.xpath('//table[@class=\'codl\']//td[starts-with(text(),"经营状态：")]/following-sibling::td/text()').extract():
            item['run_status'] = response.xpath(
            '//table[@class=\'codl\']//td[starts-with(text(),"经营状态：")]/following-sibling::td/text()').extract()


        # 所属分类：
        item['classify'] = None
        if response.xpath('//table[@class=\'codl\']//td[starts-with(text(),"所属分类：")]/following-sibling::td//text()').extract():
            item['classify'] = response.xpath('//table[@class=\'codl\']//td[starts-with(text(),"所属分类：")]/following-sibling::td//text()').extract()



        # 类型
        item['type1'] = None
        if response.xpath('//table[@class=\'codl\']//td[starts-with(text(),"类型：")]/following-sibling::td/text()').extract():
            item['type1'] = response.xpath('//table[@class=\'codl\']//td[starts-with(text(),"类型：")]/following-sibling::td/text()').extract()

        # 所属公司
        item['entname'] = None
        if response.xpath("//div[@id='biangeng']/h4[@class='boxtitle']/text()").extract():
            item['entname'] = response.xpath("//div[@id='biangeng']/h4[@class='boxtitle']/text()").extract()

        #变更事项总共
        '''
            原因：
                请求一次页面， 可以拿到多次的， 公司变更。
                可是item 设定的机制却是一次只能， 记录一次数据，返回出去给item pipline
            
            所以：
                把多次的历史变更， 放到一个list里面。返回给item pipline 然后在 item pipline 里面进行整理， 然后进行存储。
          '''
        li = []
        infos2 = response.xpath(".//div[@id='biangeng']/div/table//tr[2]//td//text()").extract()
        if response.xpath(".//div[@id='biangeng']/div/table//tr[2]//td//text()").extract():
            li.append(infos2)

        infos3 = response.xpath(".//div[@id='biangeng']/div/table//tr[3]//td//text()").extract()
        if response.xpath(".//div[@id='biangeng']/div/table//tr[3]//td//text()").extract():
            li.append(infos3)

        infos4 = response.xpath(".//div[@id='biangeng']/div/table//tr[4]//td//text()").extract()
        if response.xpath(".//div[@id='biangeng']/div/table//tr[4]//td//text()").extract():
            li.append(infos4)

        infos5 = response.xpath(".//div[@id='biangeng']/div/table//tr[5]//td//text()").extract()
        if response.xpath(".//div[@id='biangeng']/div/table//tr[5]//td//text()").extract():
            li.append(infos5)

        item['item_total'] = None
        if li:
            item['item_total'] = li

        yield item
